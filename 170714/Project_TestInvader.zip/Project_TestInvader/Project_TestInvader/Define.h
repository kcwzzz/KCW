#pragma once

#define WIDTH 80
#define HEIGHT 24

#define DIR_LEFT  0
#define DIR_RIGHT 1

#define STATE_ALIVE 0
#define STATE_DEAD 1
