#include "stdafx.h"

#include "Define.h"
#include "Bullet.h"


CBullet::CBullet()
{
}


CBullet::~CBullet()
{
}

void CBullet ::Setup() //������ X,Y ��ǥ
{

}

void  CBullet::Display(char *tpPixel) // �׷��� ǥ��
{

}

void CBullet::SetIsLife(bool tIsLife)
{
	mIsLife = tIsLife;
}